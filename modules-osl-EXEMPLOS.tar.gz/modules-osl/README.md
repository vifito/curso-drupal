#Modulos exemplo Curso Drupal OSL 2014
##exemplo01
Implementa [hook_form_alter](https://api.drupal.org/api/drupal/modules!system!system.api.php/function/hook_form_alter/7)
##exemplo02
Implementa [hook_menu](https://api.drupal.org/api/drupal/modules!system!system.api.php/function/hook_menu/7)
##exemplo03
Implementa [hook_menu](https://api.drupal.org/api/drupal/modules!system!system.api.php/function/hook_menu/7)
##exemplo04
Implementa [hook_menu](https://api.drupal.org/api/drupal/modules!system!system.api.php/function/hook_menu/7) e [simplexml_load_string](http://php.net//manual/es/function.simplexml-load-string.php)

